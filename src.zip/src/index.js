// Главный файл приложения

require('dotenv').config();
const TelegramBot = require('./bot/telegram');
const VKBot = require('./bot/vk');
const Scheduler = require('./services/scheduler');
const NotificationService = require('./services/notifications');
const GoogleSheetsService = require('./services/googleSheets');

class BeautySalonBot {
  constructor() {
    this.telegramBot = null;
    this.vkBot = null;
    this.scheduler = new Scheduler();
    this.notificationService = new NotificationService();
    this.googleSheetsService = null;
    
    this.setupGoogleSheets();
    this.setupBots();
  }

  // Настройка Google Sheets
  setupGoogleSheets() {
    try {
      const credentials = {
        client_email: process.env.GOOGLE_CLIENT_EMAIL,
        private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n')
      };
      
      this.googleSheetsService = new GoogleSheetsService(credentials);
      console.log('Google Sheets service initialized');
    } catch (error) {
      console.error('Error initializing Google Sheets service:', error);
    }
  }

  // Настройка ботов
  setupBots() {
    // Telegram бот
    if (process.env.TELEGRAM_BOT_TOKEN) {
      this.telegramBot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN);
      console.log('Telegram bot initialized');
    } else {
      console.warn('Telegram bot token not provided');
    }

    // VK бот
    if (process.env.VK_TOKEN && process.env.VK_GROUP_ID) {
      this.vkBot = new VKBot(process.env.VK_TOKEN, process.env.VK_GROUP_ID);
      console.log('VK bot initialized');
    } else {
      console.warn('VK credentials not provided');
    }
  }

  // Запуск приложения
  start() {
    console.log('Starting Beauty Salon Bot...');

    // Запуск Telegram бота
    if (this.telegramBot) {
      this.telegramBot.start();
    }

    // Запуск VK бота
    if (this.vkBot) {
      this.vkBot.start();
    }

    // Загрузка расписания из Google Sheets
    if (this.googleSheetsService) {
      this.loadScheduleFromGoogleSheets();
    }

    console.log('Beauty Salon Bot started successfully');
  }

  // Остановка приложения
  stop() {
    console.log('Stopping Beauty Salon Bot...');

    // Остановка Telegram бота
    if (this.telegramBot) {
      this.telegramBot.stop();
    }

    // Остановка VK бота
    if (this.vkBot) {
      this.vkBot.stop();
    }

    console.log('Beauty Salon Bot stopped successfully');
  }

  // Загрузка расписания из Google Sheets
  async loadScheduleFromGoogleSheets() {
    try {
      if (process.env.GOOGLE_SHEET_ID) {
        const schedule = await this.googleSheetsService.getSchedule(process.env.GOOGLE_SHEET_ID);
        console.log('Schedule loaded from Google Sheets:', schedule);
        // Здесь будет логика обновления расписания в планировщике
      } else {
        console.warn('Google Sheet ID not provided');
      }
    } catch (error) {
      console.error('Error loading schedule from Google Sheets:', error);
    }
  }
}

// Создание и запуск приложения
const app = new BeautySalonBot();

// Обработка сигналов завершения
process.on('SIGINT', () => {
  console.log('Received SIGINT signal');
  app.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('Received SIGTERM signal');
  app.stop();
  process.exit(0);
});

// Запуск приложения
app.start();

module.exports = BeautySalonBot;