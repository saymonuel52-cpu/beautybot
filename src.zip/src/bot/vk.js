// VK бот

const { VK } = require('vk-io');
const { services } = require('../config/services');
const messages = require('../config/messages');

class VKBot {
  constructor(token, groupId) {
    this.vk = new VK({
      token: token,
      pollingGroupId: groupId
    });
    
    this.setupHearManager();
  }

  // Настройка менеджера сообщений
  setupHearManager() {
    this.vk.updates.on('message_new', async (context) => {
      // Игнорируем сообщения от других ботов
      if (context.isOutbox) {
        return;
      }

      // Логирование сообщений
      console.log(`VK: ${context.senderId}: ${context.text || 'no text'}`);

      // Создание сессии пользователя
      context.session = context.session || {};
      context.session.user = context.session.user || {
        id: context.senderId,
        name: null,
        isReturning: false,
        lastService: null
      };

      // Обработка команд
      if (context.text === '/start') {
        return context.send(messages.welcome);
      }

      // Если имя еще не получено, запрашиваем его
      if (!context.session.user.name) {
        context.session.user.name = context.text;
        
        const message = context.session.user.isReturning 
          ? messages.returningUser.replace('{name}', context.text)
          : messages.newUser.replace('{name}', context.text);
        
        return context.send(message);
      }

      // Показываем главное меню
      return this.showServiceMenu(context);
    });
  }

  // Показать меню услуг
  async showServiceMenu(context) {
    const keyboard = [];
    const serviceTypes = Object.keys(services);
    
    serviceTypes.forEach(type => {
      keyboard.push([
        {
          action: {
            type: 'text',
            label: services[type].name,
            payload: JSON.stringify({ command: 'service', type: type })
          }
        }
      ]);
    });
    
    await context.send({
      message: messages.serviceSelection,
      keyboard: {
        inline: true,
        buttons: keyboard
      }
    });
  }

  // Обработка выбора услуги
  async handleServiceSelection(context, serviceType) {
    context.session.selectedServiceType = serviceType;
    
    // Показать подкатегории услуги
    const serviceItems = services[serviceType].items;
    const keyboard = [];
    
    Object.keys(serviceItems).forEach(key => {
      const item = serviceItems[key];
      keyboard.push([
        {
          action: {
            type: 'text',
            label: `${item.name} (${item.duration} мин, ${item.price} руб)`,
            payload: JSON.stringify({ command: 'service_item', type: serviceType, key: key })
          }
        }
      ]);
    });
    
    keyboard.push([
      {
        action: {
          type: 'text',
          label: 'Назад',
          payload: JSON.stringify({ command: 'back_to_services' })
        }
      }
    ]);
    
    await context.send({
      message: 'Пожалуйста, выберите конкретную услугу:',
      keyboard: {
        inline: true,
        buttons: keyboard
      }
    });
  }

  // Запуск бота
  start() {
    this.vk.updates.startPolling();
    console.log('VK bot started');
  }

  // Остановка бота
  stop() {
    this.vk.updates.stopPolling();
    console.log('VK bot stopped');
  }
}

module.exports = VKBot;