// Система управления расписанием

class Scheduler {
  constructor() {
    this.schedule = {};
    this.timeSlots = [];
    this.setupDefaultSchedule();
  }

  // Настройка расписания по умолчанию
  setupDefaultSchedule() {
    // Рабочие дни с понедельника по субботу
    const weekdays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    
    weekdays.forEach(day => {
      this.schedule[day] = {
        working: true,
        start: '09:00',
        end: '20:00',
        breaks: [
          { start: '13:00', end: '14:00' }
        ]
      };
    });
    
    // Воскресенье - выходной
    this.schedule.sunday = {
      working: false
    };
    
    // Генерация временных слотов
    this.generateTimeSlots();
  }

  // Генерация временных слотов
  generateTimeSlots() {
    this.timeSlots = [];
    
    // Для каждого рабочего дня
    Object.keys(this.schedule).forEach(day => {
      const daySchedule = this.schedule[day];
      
      if (daySchedule.working) {
        // Генерация слотов по 30 минут
        let currentTime = this.timeToMinutes(daySchedule.start);
        const endTime = this.timeToMinutes(daySchedule.end);
        
        while (currentTime < endTime) {
          // Проверка перерывов
          const isBreak = daySchedule.breaks.some(breakSlot => {
            const breakStart = this.timeToMinutes(breakSlot.start);
            const breakEnd = this.timeToMinutes(breakSlot.end);
            return currentTime >= breakStart && currentTime < breakEnd;
          });
          
          if (!isBreak) {
            this.timeSlots.push({
              day: day,
              time: this.minutesToTime(currentTime),
              available: true
            });
          }
          
          currentTime += 30; // 30 минут
        }
      }
    });
  }

  // Преобразование времени в минуты
  timeToMinutes(time) {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }

  // Преобразование минут в время
  minutesToTime(minutes) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
  }

  // Получение доступных временных слотов
  getAvailableSlots(date, duration) {
    // Пока возвращаем заглушку
    return [
      { date: '2026-01-10', time: '10:00', duration: 30 },
      { date: '2026-01-10', time: '11:00', duration: 30 },
      { date: '2026-01-10', time: '14:30', duration: 30 },
      { date: '2026-01-11', time: '12:00', duration: 30 },
      { date: '2026-01-11', time: '15:30', duration: 30 }
    ];
  }

  // Бронирование слота
  bookSlot(date, time, userId, service) {
    // Пока возвращаем заглушку
    return {
      success: true,
      bookingId: 'booking_' + Date.now(),
      date: date,
      time: time,
      userId: userId,
      service: service
    };
  }

  // Отмена бронирования
  cancelBooking(bookingId) {
    // Пока возвращаем заглушку
    // TODO: Добавить проверку времени отмены (минимум за 12 часов)
    return {
      success: true,
      message: 'Бронирование успешно отменено'
    };
  }

  // Получение расписания из Google Sheets
  async loadScheduleFromGoogleSheets() {
    // Здесь будет логика загрузки расписания из Google Sheets
    // Пока используем заглушку
    console.log('Загрузка расписания из Google Sheets');
  }

  // Сохранение расписания в Google Sheets
  async saveScheduleToGoogleSheets() {
    // Здесь будет логика сохранения расписания в Google Sheets
    // Пока используем заглушку
    console.log('Сохранение расписания в Google Sheets');
  }

  // Проверка режима отпуска
  checkVacationMode() {
    // Здесь будет логика проверки режима отпуска
    // Пока используем заглушку
    console.log('Проверка режима отпуска');
    return false;
  }
}

module.exports = Scheduler;